from django.apps import AppConfig


class VerifPlayGroundAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'verif_play_ground_app'
